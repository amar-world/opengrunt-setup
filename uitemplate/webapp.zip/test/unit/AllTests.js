sap.ui.define([
	"com/golit/ut/uitemplate/test/unit/controller/Main.controller"
], function () {
	"use strict";
});